import styled from 'styled-components'
export const Container = styled.form`
    padding:32px;
    display:flex;
    flex-direction: column;
    width:${({width}) => width};
    border-radius: 30px;
    background-color:grey;
    height:${({height}) => height};
    justify-content:space-between;
`

export const Line = styled.div`
    position:relative;
    top:-2px;
    width:100%;
    height:0px;
    border-bottom:2px pink solid;
    transform:${({active}) => active?"scaleX(1)":"scaleX(0)"};
    transition:all 0.5s;

`
export const Label = styled.label`
    position: absolute;
    left: 0;
    color:black;
    transition:all 0.5s;
    transform:${({active}) => active?"translateY(-50px)":"translateY(-30px)"};

` 
export const Input = styled.input`
    width:100%;
    outline:none;
    border:none;
    background-color:inherit;
    border-bottom: 2px black solid;
`

export const InputWrapper = styled.div`
    margin-bottom:${({margin})=> margin};
    position: relative;
    width:100%;
    ${Input}:focus{
        ~${Line}{
            transform:scaleX(1);
        }
        ~${Label}{
            transform:translateY(-50px);
        }
     }
`

export const TextArea = styled.textarea`
padding:30px;
border-radius: 30px;
     outline:none;
    border:none;
    width:100%;
    min-height:200px;
`
