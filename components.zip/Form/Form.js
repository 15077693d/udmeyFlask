import React from 'react';
import {Container, Input, InputWrapper, Line, Label, TextArea} from './Form.elements'
const Form = ({children, ...otherProps}) => {
    return (
        <Container {...otherProps}>
             {children}
        </Container>
    );
};

export default Form;

Form.Input = ({ placeholder,value, margin ,onChange}) => {
  return <InputWrapper margin={margin}>
            <Input onChange={onChange} value={value}/>
            <Line active={value!==""}/>
            <Label active={value!==""}>{placeholder}</Label>
        </InputWrapper>
}

Form.TextArea = ({ placeholder, value,onChange }) => {
    return <TextArea onChange={onChange} placeholder={placeholder} value={value}/>
  }

// Navbar. = ({ children, ...otherProps }) => {
//   return <Item {...otherProps}>{children}</Item>
// }

// Navbar.Link = ({ children, ...otherProps }) => {
//   return <Link {...otherProps}>{children}</Link>
// }

// Navbar.Leading = ({ children, ...otherProps }) => {
//   return <Leading {...otherProps}>{children}</Leading>
// }

// Navbar.Image = ({ src, alt, maxWidth, children, ...otherProps }) => {
//   return (
//     <Image src={src} alt={alt} maxWidth={maxWidth} {...otherProps}>
//       {children}
//     </Image>
//   )
// }

