import styled from 'styled-components'

export const Image = styled.img`
  margin: 15px;
  width:200px;
  transition: all 0.3s;
  opacity:0.5;
  filter: grayscale(100%);
  &:hover{
    opacity:1;
    filter: grayscale(0%);
  }
`

export const Container = styled.div`
    width:${({width}) => width};
    display: flex;
    flex-flow:row wrap;
    justify-content:center
`