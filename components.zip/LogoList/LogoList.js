import logo from './logo.png'
import React from 'react';
import {Image, Container} from './LogoList.elements'
import styled from 'styled-components';
const ClientList = () => {
  return <Container >
    <Image src={logo}/>
    <Image src={logo}/>
    <Image src={logo}/>
    <Image src={logo}/>
    <Image src={logo}/>
    <Image src={logo}/>
    <Image src={logo}/>
  </Container>
}

const PartershipList = () => {
  return <Container>
  <Image src={logo}/>
  <Image src={logo}/>
</Container>
}

const Wrapper = styled.div`
  /* width:600px; */
  height:300px;
  display:flex;
  flex-direction: column;
  justify-content:space-between;
  align-items:center;
`
const LogoList = () => {
  return (
    <Wrapper>
      <span>sentence1</span>
      <ClientList/>
      <span>sentence2</span>
      <PartershipList/>
    </Wrapper>
  );
};

export default LogoList;
